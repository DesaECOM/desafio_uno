package com.desafio.uno.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "client")
public class Client {
	
	private Long id;
	private String fullName;
	private String rut;
	private String businessName;
	private Timestamp startDate;
	private List<EnergyMeter> EnergyMeters;
	
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "full_name", nullable = false)
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String nombre) {
		this.fullName = nombre;
	}
	
	@Column(name = "rut", nullable = false)
	public String getRut() {
		return rut;
	}
	public void setRut(String rut) {
		this.rut = rut;
	}
	
	@Column(name = "business_name", nullable = false)
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String razonSocial) {
		this.businessName = razonSocial;
	}
	
	@Column(name = "start_date", nullable = false)
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	
	@OneToMany(mappedBy="client", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public List<EnergyMeter> getEnergyMeters() {
		return EnergyMeters;
	}
	public void setEnergyMeters(List<EnergyMeter> eMeters) {
		this.EnergyMeters = eMeters;
	}
	
	
	
	
	
}
