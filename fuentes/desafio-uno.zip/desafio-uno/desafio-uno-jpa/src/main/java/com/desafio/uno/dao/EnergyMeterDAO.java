package com.desafio.uno.dao;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.desafio.uno.entity.EnergyMeter;

public class EnergyMeterDAO {

	@PersistenceContext(name="desafio-uno")
	private EntityManager em;
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(EnergyMeter medidor) throws Exception{
		em.persist(medidor);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public EnergyMeter getEnergyMeter(String idEMeter){
		return em.find(EnergyMeter.class, idEMeter);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void delete(EnergyMeter m) {
		em.remove(m);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public EnergyMeter update(EnergyMeter m) {
		return em.merge(m);
	}
	
}
