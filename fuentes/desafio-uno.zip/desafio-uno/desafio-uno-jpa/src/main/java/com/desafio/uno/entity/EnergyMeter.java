package com.desafio.uno.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "energy_meter")
public class EnergyMeter {

	private Long id;
	private String idEnergyMeter;
	private String address;
	private String installationNumber;
	private String evolId;
	private Client client;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIdMedidor() {
		return idEnergyMeter;
	}
	public void setIdMedidor(String idMedidor) {
		this.idEnergyMeter = idMedidor;
	}
	
	@Column(name = "address", nullable = false)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Column(name = "installation_number", nullable = false)
	public String getInstallationNumber() {
		return installationNumber;
	}
	public void setInstallationNumber(String installationNumber) {
		this.installationNumber = installationNumber;
	}
	
	@Column(name = "evo_id", nullable = false)
	public String getEvolId() {
		return evolId;
	}
	public void setEvolId(String evolId) {
		this.evolId = evolId;
	}
	
	@ManyToOne
    @JoinColumn(name = "id_client", nullable = false)
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	
	
	
	
	
}
