package com.desafio.uno.dao;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.desafio.uno.entity.Client;

@Stateless
public class ClientDAO {

	@PersistenceContext(name="desafio-uno")
	private EntityManager em;
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(Client client) throws Exception{
		em.persist(client);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Client getCliente(String rut){
		return em.find(Client.class, rut);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void delete(Client c) {
		em.remove(c);
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Client update(Client c) {
		return em.merge(c);
	}
	
}
