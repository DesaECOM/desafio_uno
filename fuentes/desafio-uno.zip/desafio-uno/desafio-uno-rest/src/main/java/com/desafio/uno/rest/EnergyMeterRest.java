package com.desafio.uno.rest;

import javax.ejb.Local;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.desafio.uno.pojo.ServiceOutput;
import com.desafio.uno.restimpl.EnergyMeterRestImpl;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Local
@Path("/medidor/")
public class EnergyMeterRest {

	@Inject
	private EnergyMeterRestImpl medidorRestImpl;
	

	@GET
	@POST
	@Produces(MediaType.APPLICATION_JSON)
    @Path("guardar")
	public Response guardar(String json, @Context HttpHeaders headers){
		ServiceOutput respuesta = medidorRestImpl.guardar(json, headers);
		Gson gson = new GsonBuilder().create();
		String jsonOut = gson.toJson(respuesta);
		return Response.ok(jsonOut).build();
	}
	
	@GET
	@POST
	@Produces(MediaType.APPLICATION_JSON)
    @Path("actualizar")
	public Response actualizar(String json, @Context HttpHeaders headers){
		ServiceOutput respuesta = medidorRestImpl.actualizar(json, headers);
		Gson gson = new GsonBuilder().create();
		String jsonOut = gson.toJson(respuesta);
		return Response.ok(jsonOut).build();
	}
	
	@GET
	@POST
	@Produces(MediaType.APPLICATION_JSON)
    @Path("eliminar")
	public Response eliminar(String json, @Context HttpHeaders headers){
		ServiceOutput respuesta = medidorRestImpl.eliminar(json, headers);
		Gson gson = new GsonBuilder().create();
		String jsonOut = gson.toJson(respuesta);
		return Response.ok(jsonOut).build();
	}
	
	@GET
	@POST
	@Produces(MediaType.APPLICATION_JSON)
    @Path("consultar")
	public Response consultar(String json, @Context HttpHeaders headers){
		ServiceOutput respuesta = medidorRestImpl.consultar(json, headers);
		Gson gson = new GsonBuilder().create();
		String jsonOut = gson.toJson(respuesta);
		return Response.ok(jsonOut).build();
	}
	
	
}
