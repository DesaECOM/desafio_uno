package com.desafio.uno.pojo;

public class EnergyMeterPojo {

	
	private String idMedidor;
	private String direccionFisica;
	private String numeroInstalaci�n;
	private String evolId;
	private String idCliente;
	
	
	public String getIdMedidor() {
		return idMedidor;
	}
	public void setIdMedidor(String idMedidor) {
		this.idMedidor = idMedidor;
	}
	public String getDireccionFisica() {
		return direccionFisica;
	}
	public void setDireccionFisica(String direccionFisica) {
		this.direccionFisica = direccionFisica;
	}
	public String getNumeroInstalaci�n() {
		return numeroInstalaci�n;
	}
	public void setNumeroInstalaci�n(String numeroInstalaci�n) {
		this.numeroInstalaci�n = numeroInstalaci�n;
	}
	public String getEvolId() {
		return evolId;
	}
	public void setEvolId(String evolId) {
		this.evolId = evolId;
	}
	public String getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}
	
	
	
	
}
