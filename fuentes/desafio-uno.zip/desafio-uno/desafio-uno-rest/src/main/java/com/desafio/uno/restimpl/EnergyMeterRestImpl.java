package com.desafio.uno.restimpl;

import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;

import com.desafio.uno.dao.ClientDAO;
import com.desafio.uno.dao.EnergyMeterDAO;
import com.desafio.uno.entity.Client;
import com.desafio.uno.entity.EnergyMeter;
import com.desafio.uno.pojo.ClientPojo;
import com.desafio.uno.pojo.EnergyMeterPojo;
import com.desafio.uno.pojo.ServiceOutput;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class EnergyMeterRestImpl {

	@Inject
	private EnergyMeterDAO medidorDAO;
	
	public ServiceOutput guardar(String json, HttpHeaders headers) {
		ServiceOutput out =  new ServiceOutput();
		EnergyMeter m = new EnergyMeter();
		
		Gson gson = new GsonBuilder().create();
		EnergyMeterPojo medidorPojo = gson.fromJson(json, EnergyMeterPojo.class);
		
		m.setAddress(medidorPojo.getDireccionFisica());
		m.setEvolId(medidorPojo.getEvolId());
		m.setIdMedidor(medidorPojo.getIdMedidor());
		m.setInstallationNumber(medidorPojo.getNumeroInstalaci�n());
		
		try {
			medidorDAO.save(m);
			out.setCodigo("1");
			out.setComentario("Guardado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput actualizar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		EnergyMeterPojo medidorPojo = gson.fromJson(json, EnergyMeterPojo.class);
		
		EnergyMeter m = medidorDAO.getEnergyMeter(medidorPojo.getIdMedidor());
		
		m.setAddress(json);
		
		m.setAddress(medidorPojo.getDireccionFisica());
		m.setEvolId(medidorPojo.getEvolId());
		m.setIdMedidor(medidorPojo.getIdMedidor());
		m.setInstallationNumber(medidorPojo.getNumeroInstalaci�n());
		
		try {
			medidorDAO.update(m);
			out.setCodigo("1");
			out.setComentario("Guardado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput eliminar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		EnergyMeterPojo medidorPojo = gson.fromJson(json, EnergyMeterPojo.class);
		
		EnergyMeter m = medidorDAO.getEnergyMeter(medidorPojo.getIdMedidor());
		
		try {
			medidorDAO.delete(m);
			out.setCodigo("1");
			out.setComentario("Eliminado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput consultar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		EnergyMeterPojo medidorPojo = gson.fromJson(json, EnergyMeterPojo.class);
		
		try {
			EnergyMeter c = medidorDAO.getEnergyMeter(medidorPojo.getIdMedidor());
			
			out.setCodigo("1");
			out.setComentario("Datos Obtenidos");
			out.setEstado("OK");
			out.setData(c.toString());
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
