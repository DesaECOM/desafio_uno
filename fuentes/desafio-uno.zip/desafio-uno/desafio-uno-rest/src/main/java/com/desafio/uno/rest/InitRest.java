package com.desafio.uno.rest;



import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("/services")
public class InitRest extends Application {

}
