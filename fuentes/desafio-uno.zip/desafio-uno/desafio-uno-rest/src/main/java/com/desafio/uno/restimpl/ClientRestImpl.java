package com.desafio.uno.restimpl;

import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;

import com.desafio.uno.dao.ClientDAO;
import com.desafio.uno.entity.Client;
import com.desafio.uno.pojo.ClientPojo;
import com.desafio.uno.pojo.ServiceOutput;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ClientRestImpl {

	@Inject
	private ClientDAO clienteDAO;
	
	public ServiceOutput guardar(String json, HttpHeaders headers) {
		ServiceOutput out =  new ServiceOutput();
		Client c = new Client();
		
		Gson gson = new GsonBuilder().create();
		ClientPojo clientePojo = gson.fromJson(json, ClientPojo.class);
		
		c.setStartDate(clientePojo.getFechaInicio());
		c.setFullName(clientePojo.getNombre());
		c.setBusinessName(clientePojo.getRazonSocial());
		c.setRut(clientePojo.getRut());
		
		try {
			clienteDAO.save(c);
			out.setCodigo("1");
			out.setComentario("Guardado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput actualizar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		ClientPojo clientePojo = gson.fromJson(json, ClientPojo.class);
		
		Client c = clienteDAO.getCliente(clientePojo.getRut());
		
		c.setStartDate(clientePojo.getFechaInicio());
		c.setFullName(clientePojo.getNombre());
		c.setBusinessName(clientePojo.getRazonSocial());
		c.setRut(clientePojo.getRut());
		
		try {
			clienteDAO.update(c);
			out.setCodigo("1");
			out.setComentario("Actualizado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput eliminar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		ClientPojo clientePojo = gson.fromJson(json, ClientPojo.class);
		
		Client c = clienteDAO.getCliente(clientePojo.getRut());
		
		try {
			clienteDAO.delete(c);
			out.setCodigo("1");
			out.setComentario("Eliminado Correctamente");
			out.setEstado("OK");
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public ServiceOutput consultar(String json, HttpHeaders headers) {
		
		ServiceOutput out =  new ServiceOutput();
		
		Gson gson = new GsonBuilder().create();
		ClientPojo clientePojo = gson.fromJson(json, ClientPojo.class);
		
		try {
			Client c = clienteDAO.getCliente(clientePojo.getRut());
			
			out.setCodigo("1");
			out.setComentario("Datos Obtenidos");
			out.setEstado("OK");
			out.setData(c.toString());
			
			return out;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
