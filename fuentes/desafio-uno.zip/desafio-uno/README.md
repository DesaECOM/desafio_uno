Wildfly 23.0.2 : https://download.jboss.org/wildfly/23.0.2.Final/wildfly-23.0.2.Final.zip

PostgreSQL 

Java 1.8.0_291
Maven 3.8.1 : https://maven.apache.org/download.cgi


AGREGAR DATASOURCE EN ARCHIVO wildfly-23.0.2.Final/standalone/configuration/standalone.xlm:

<datasource jndi-name="java:/backoffice-service" pool-name="backoffice_service" enabled="true" use-java-context="true" statistics-enabled="${wildfly.datasources.statistics-enabled:${wildfly.statistics-enabled:false}}">
    <connection-url>jdbc:postgresql://localhost:5432/desafio_uno</connection-url>
    <driver>postgresql</driver>
    <security>
        <user-name>postgres</user-name>
        <password>postgres</password>
    </security>
</datasource>
<drivers>
    <driver name="h2" module="com.h2database.h2">
        <xa-datasource-class>org.h2.jdbcx.JdbcDataSource</xa-datasource-class>
    </driver>
    <driver name="postgresql" module="org.postgresql"/>
</drivers>

CREAR BASE DE DATOS CON EL NOMBRE: desafio_uno


LEVANTAR PROYECTO:

Click secundario sobre el proyecto -> Run As -> Maven Build , en 'goals' escribir 'clean install' -> Run.

El proyecto hace deploy autom�tico en el servidor al correrlo, no queda el archivo war en standalone/deployments ya que no se hace el deploy manualmente.

Si se requiere el archivo war, se encuentra en el m�dulo web -> web/target
